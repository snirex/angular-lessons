import { Component } from '@angular/core';

@Component({
  selector: 'app-movi',
  templateUrl: './movi.component.html',
  styleUrl: './movi.component.scss'
})
export class MoviComponent {

}
