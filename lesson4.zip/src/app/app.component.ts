import { Component } from '@angular/core';

@Component({
  // metadata: which files are in use in our project
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  title = 'lesson4';
}
