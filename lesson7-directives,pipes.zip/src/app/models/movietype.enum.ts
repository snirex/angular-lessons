export enum MovieType{
    Action = "Action",
    Drama = "Drama",
    Israeli = "Israeli"
}